import React, { useState } from 'react';
import './App.css';

function App() {
  const [form, setForm] = useState({
    nome: '',
    email: '',
    telefone: '',
    tipo: '',
  });
  const [cotacoes, setCotacoes] = useState([]);
  const [exibirResultados, setExibirResultados] = useState(false);

  const operadoras = {
    auto: [
      { nome: 'SeguroFácil', preco: 1200, cobertura: 'Básica' },
      { nome: 'TopSeguros', preco: 1500, cobertura: 'Completa' },
      { nome: 'ProtegeJá', preco: 1350, cobertura: 'Intermediária' }
    ],
    residencial: [
      { nome: 'CasaSegura', preco: 300, cobertura: 'Incêndio e roubo' },
      { nome: 'LarProtegido', preco: 400, cobertura: 'Total' }
    ],
    vida: [
      { nome: 'VidaBem', preco: 50, cobertura: 'Acidente e Doença' },
      { nome: 'VidaPremium', preco: 80, cobertura: 'Completa + Funeral' }
    ]
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const resultados = operadoras[form.tipo] || [];
    setCotacoes(resultados);
    setExibirResultados(true);
  };

  return (
    <div className="container">
      <h1>Baratão Seguros</h1>
      <p>Compare preços de várias seguradoras e escolha a melhor opção!</p>
      <form onSubmit={handleSubmit}>
        <input type="text" name="nome" placeholder="Seu nome" value={form.nome} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Seu e-mail" value={form.email} onChange={handleChange} required />
        <input type="tel" name="telefone" placeholder="Seu telefone" value={form.telefone} onChange={handleChange} required />
        <select name="tipo" value={form.tipo} onChange={handleChange} required>
          <option value="">Escolha o tipo de seguro</option>
          <option value="auto">Seguro Auto</option>
          <option value="residencial">Seguro Residencial</option>
          <option value="vida">Seguro de Vida</option>
        </select>
        <button type="submit">Simular Multicálculo</button>
      </form>

      {exibirResultados && (
        <div className="resultado">
          <h2>Resultados:</h2>
          {cotacoes.map((c, i) => (
            <div key={i} className="cotacao">
              <strong>{c.nome}</strong><br />
              Preço: R$ {c.preco} <br />
              Cobertura: {c.cobertura}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
